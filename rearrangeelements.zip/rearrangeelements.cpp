#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector<int> arr={2,3,-1,-4,4,-3};
    int n=arr.size();
    vector<int>ans(n,0);
    int pos=0, neg=1;
    for(int i=0;i<n;i++){
        if(arr[i]>0){
            ans[pos]=arr[i];
            pos=pos+2;
        }
        else{
            ans[neg]=arr[i];
            neg=neg+2;
        }    

    }
    for(int i=0;i<n;i++){
        cout<<ans[i]<<" ";
    }

    
    
}